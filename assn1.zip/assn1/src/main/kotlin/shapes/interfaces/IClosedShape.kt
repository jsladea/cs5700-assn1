package shapes.interfaces

interface IClosedShape {
    fun area(): Double
}