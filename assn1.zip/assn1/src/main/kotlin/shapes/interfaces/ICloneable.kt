package shapes.interfaces

interface ICloneable<T> {
    fun clone(): T
}