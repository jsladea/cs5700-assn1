package shapes.interfaces

interface IMoveable {
    fun move(dx: Double, dy: Double)
}